#include "Watchy_FooFingers.h"

WatchyFooFingers::WatchyFooFingers(){} //constructor

void WatchyFooFingers::drawWatchFace(){
    display.fillScreen(GxEPD_BLACK);
    display.drawBitmap(0, 0, bg, DISPLAY_WIDTH, DISPLAY_HEIGHT, GxEPD_BLACK);
  
    int x = 100;
    int y = 125;
      
    int16_t x1, y1;
    uint16_t w, h;

    String s_currentTime = "";
    
    if(currentTime.Hour < 10){
       s_currentTime.concat("0");
    }
    s_currentTime.concat(currentTime.Hour);
    s_currentTime.concat(":");
    if(currentTime.Minute < 10){
      s_currentTime.concat("0");
    }
    s_currentTime.concat(currentTime.Minute);
    
    display.setTextColor(GxEPD_WHITE);
    display.setFont(&MADESunflower_trim38pt7b);
    display.setTextWrap(false);
    display.getTextBounds(s_currentTime, x, y, &x1, &y1, &w, &h);
    display.setCursor(x - w / 2, y);
    display.print(s_currentTime);

    /* Other functions */

    this->drawDate();
}

void WatchyFooFingers::drawDate(){
    String s_currentDate = "";
    String dayOfWeek = dayStr(currentTime.Wday);
    String curMonth = monthShortStr(currentTime.Month);

    s_currentDate.concat(dayOfWeek);
    s_currentDate.concat(", ");
    s_currentDate.concat(curMonth);
    s_currentDate.concat(" ");
    s_currentDate.concat(currentTime.Day);

    switch (currentTime.Day){
      case 1:
      case 21:
      case 31:
        s_currentDate.concat("st");
      break;
      case 2:
      case 22:
        s_currentDate.concat("nd");
      break;
      case 3:
      case 23:
        s_currentDate.concat("rd");
      break;
      default:
        s_currentDate.concat("th");
      break;
    }
    
    display.setTextColor(GxEPD_WHITE);
    display.setFont(&MotorolaScreentype10pt7b);
    display.setTextWrap(false);
    display.setCursor(5,20);
    display.print(s_currentDate);
}
